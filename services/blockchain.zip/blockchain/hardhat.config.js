require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();
require("@nomiclabs/hardhat-ethers");

const { ETH_RPC_URL, ETH_CHAIN_ID, ETH_PRIVATE_KEY } = process.env;

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.19", // même version que ton contrat
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  defaultNetwork: "localhost",
  networks: {
    localhost: {
      url: ETH_RPC_URL || "http://127.0.0.1:8545",
      chainId: Number(ETH_CHAIN_ID) || 1337,
      accounts: ETH_PRIVATE_KEY ? [ETH_PRIVATE_KEY] : [],
    },
  },
  paths: {
    sources: "./services/blockchain-service/contracts", // dossier de tes contrats
    tests: "./services/blockchain-service/test",
    cache: "./services/blockchain-service/cache",
    artifacts: "./services/blockchain-service/artifacts",
  },
};
