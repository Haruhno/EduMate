#!/usr/bin/env node

import ganache from "ganache";
import { spawn } from "child_process";
import http from "http";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GANACHE_PORT = process.env.ETH_PORT || 8545;
const GANACHE_URL = `http://localhost:${GANACHE_PORT}`;
const MAX_RETRIES = 30;
const MNEMONIC = 'test walk nut penalty hip pave soap entry language right filter choice';

let ganacheServer = null;
let goService = null;

// Vérifie si Ganache est prêt
function isGanacheReady() {
  return new Promise((resolve) => {
    const postData = JSON.stringify({ jsonrpc: '2.0', method: 'eth_chainId', params: [], id: 1 });
    const options = {
      hostname: 'localhost',
      port: GANACHE_PORT,
      path: '/',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': postData.length },
      timeout: 2000
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => { try { resolve(!!JSON.parse(data).result); } catch { resolve(false); } });
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
    req.write(postData);
    req.end();
  });
}

// Attend que Ganache soit prêt
async function waitForGanache() {
  let retries = 0;
  console.log('⏳ Attente du démarrage de Ganache...');
  while (retries < MAX_RETRIES) {
    if (await isGanacheReady()) {
      console.log('✅ Ganache est prêt!\n');
      return true;
    }
    process.stdout.write('.');
    retries++;
    await new Promise(res => setTimeout(res, 1000));
  }
  console.error('\n❌ Ganache n\'a pas démarré dans le délai imparti');
  return false;
}

// Recompile server.exe
async function buildGoServer(projectRoot) {
  return new Promise((resolve, reject) => {
    console.log('🔨 Compilation du Blockchain Service...');
    const buildProcess = spawn('go', ['build', '-o', 'server.exe', './cmd/server'], {
      cwd: path.join(projectRoot, 'services', 'blockchain-service'),
      stdio: 'inherit'
    });

    buildProcess.on('close', (code) => {
      if (code === 0) {
        console.log('✅ Compilation réussie\n');
        resolve();
      } else {
        reject(new Error(`Build failed with code ${code}`));
      }
    });
  });
}

// Arrêt propre
async function cleanup() {
  console.log('\n🛑 Arrêt des services...');
  if (goService) goService.kill('SIGTERM');
  if (ganacheServer) {
    try { await ganacheServer.close(); console.log('✅ Ganache arrêté proprement'); }
    catch (err) { console.error('❌ Erreur lors de l\'arrêt de Ganache:', err.message); }
  }
  process.exit(0);
}

// Crée .env si inexistant
function ensureEnv(projectRoot) {
  const envPath = path.join(projectRoot, 'services', 'blockchain-service', '.env');
  if (!fs.existsSync(envPath)) {
    fs.writeFileSync(envPath, `ETH_RPC_URL=${GANACHE_URL}\nETH_CHAIN_ID=1337\n`);
    console.log('📝 .env créé automatiquement dans blockchain-service');
  }
}

// Main
async function main() {
  try {
    const projectRoot = path.resolve(__dirname, '..', '..');
    ensureEnv(projectRoot);

    console.log('📦 Lancement de Ganache (via Node.js)...');
    ganacheServer = ganache.server({
      wallet: { mnemonic: MNEMONIC, totalAccounts: 10, defaultBalance: 1000 },
      chain: { networkId: 1337, chainId: 1337 },
      logging: { quiet: false, verbose: false }
    });
    await ganacheServer.listen(GANACHE_PORT);
    console.log(`✅ Ganache démarré sur ${GANACHE_URL}\n`);

    const ready = await waitForGanache();
    if (!ready) throw new Error('Ganache did not become ready in time');

    // 🔨 Recompile avant lancement
    await buildGoServer(projectRoot);

    console.log('🐹 Lancement du Blockchain Service (server.exe)...\n');
    const exePath = path.join(projectRoot, 'services', 'blockchain-service', 'server.exe');

    goService = spawn(exePath, [], {
      stdio: 'inherit',
      env: { ...process.env, ETH_RPC_URL: GANACHE_URL, ETH_CHAIN_ID: '1337' }
    });

    goService.on('error', (err) => {
      console.error('❌ Erreur démarrage blockchain-service:', err.message);
      console.log('💡 Vérifie que server.exe existe et est exécutable');
      cleanup();
    });

    goService.on('close', (code) => {
      console.log(`\n🛑 Blockchain Service exited with code ${code}`);
      cleanup();
    });

  } catch (err) {
    console.error('❌ Erreur:', err.message);
    await cleanup();
  }
}

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

main().catch(err => { console.error('❌ Erreur fatale:', err); process.exit(1); });
