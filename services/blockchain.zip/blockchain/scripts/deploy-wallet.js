const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  const [deployer] = await hre.ethers.getSigners();

  console.log("Déploiement du contrat EduMateWallet avec:", deployer.address);
  console.log("Solde du déployeur:", (await deployer.getBalance()).toString());

  // Déployer le contrat
  const EduMateWallet = await hre.ethers.getContractFactory("EduMateWallet");
  console.log("Déploiement en cours...");
  const wallet = await EduMateWallet.deploy();
  await wallet.waitForDeployment();

  const address = await wallet.getAddress();
  console.log("✅ Contrat déployé à l'adresse:", address);

  // Mettre à jour automatiquement le .env
  const envPath = path.resolve(__dirname, "services/blockchain-service/.env");
  let envContent = fs.readFileSync(envPath, "utf-8");

  if (envContent.includes("CONTRACT_ADDRESS=")) {
    envContent = envContent.replace(/CONTRACT_ADDRESS=.*/g, `CONTRACT_ADDRESS=${address}`);
  } else {
    envContent += `\nCONTRACT_ADDRESS=${address}\n`;
  }

  fs.writeFileSync(envPath, envContent);
  console.log("📝 .env mis à jour automatiquement avec CONTRACT_ADDRESS");

  // --- Test rapide du contrat ---
  console.log("\n🧪 Test du contrat:");

  const testUserId = "test-user-123";
  console.log(`Création du wallet pour: ${testUserId}`);
  const tx = await wallet.createWallet(testUserId);
  await tx.wait();

  const walletAddress = await wallet.getWalletByUser(testUserId);
  console.log(`Adresse générée pour ${testUserId}: ${walletAddress}`);

  const balance = await wallet.getBalance(walletAddress);
  console.log(`Solde initial: ${balance[0].toString()} crédits`);

  const userIdFromWallet = await wallet.getUserByWallet(walletAddress);
  console.log(`Utilisateur récupéré depuis l'adresse: ${userIdFromWallet}`);
}

main().catch((error) => {
  console.error("❌ Erreur:", error);
  process.exitCode = 1;
});
