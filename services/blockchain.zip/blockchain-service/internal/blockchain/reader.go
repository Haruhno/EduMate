package blockchain

import (
	"math/big"
	"time"

	"blockchain-service/internal/blockchain/ethereum"

	"github.com/ethereum/go-ethereum/common"
)

type BlockchainReader interface {
	GetBalance(address common.Address) (*ethereum.WalletBalance, error)
	GetTransactionHistory(address common.Address, page, limit uint64, startDate, endDate uint64) ([]ethereum.Transaction, uint64, error)
	GetStats(address common.Address) (*ethereum.WalletStats, error)
	GetChainInfo() (*ChainInfo, error)
	GenerateAuditReport(address common.Address, startDate, endDate uint64) (*ethereum.AuditReport, error)
}

type ChainInfo struct {
	TotalBlocks    uint64
	LastBlockHash  common.Hash
	LastBlockTime  time.Time
	ChainID        *big.Int
	IsValid        bool
}

type EthereumReader struct {
	client *ethereum.Client
}

func NewEthereumReader(client *ethereum.Client) *EthereumReader {
	return &EthereumReader{client: client}
}

func (r *EthereumReader) GetBalance(address common.Address) (*ethereum.WalletBalance, error) {
	return r.client.GetBalance(address)
}

func (r *EthereumReader) GetTransactionHistory(
	address common.Address,
	page, limit uint64,
	startDate, endDate uint64,
) ([]ethereum.Transaction, uint64, error) {
	return r.client.GetTransactionHistory(address, page, limit, startDate, endDate)
}

func (r *EthereumReader) GetStats(address common.Address) (*ethereum.WalletStats, error) {
	return r.client.GetStats(address)
}

func (r *EthereumReader) GenerateAuditReport(
	address common.Address,
	startDate, endDate uint64,
) (*ethereum.AuditReport, error) {
	return r.client.GenerateAuditReport(address, startDate, endDate)
}	