package blockchain

import (
	"math/big"

	"blockchain-service/internal/blockchain/ethereum"

	"github.com/ethereum/go-ethereum/common"
)

type BlockchainWriter interface {
	Transfer(from, to common.Address, amount *big.Int, description, txType string) (common.Hash, error)
	RequestWithdrawal(address common.Address, amount *big.Int, bankDetailsJSON string) (common.Hash, error)
	CreateWallet(address common.Address) (common.Address, error)
}

type EthereumWriter struct {
	client *ethereum.Client
}

func NewEthereumWriter(client *ethereum.Client) *EthereumWriter {
	return &EthereumWriter{client: client}
}

func (w *EthereumWriter) Transfer(
	from, to common.Address,
	amount *big.Int,
	description, txType string,
) (common.Hash, error) {
	return w.client.Transfer(from, to, amount, description, txType)
}

func (w *EthereumWriter) RequestWithdrawal(
	address common.Address,
	amount *big.Int,
	bankDetailsJSON string,
) (common.Hash, error) {
	return w.client.RequestWithdrawal(address, amount, bankDetailsJSON)
}

func (w *EthereumWriter) CreateWallet(address common.Address) (common.Address, error) {
	// Implémenter via le smart contract
	// Pour l'instant, retourner la même adresse
	return address, nil
}