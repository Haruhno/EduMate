package ethereum

import (
	"math/big"

	"github.com/ethereum/go-ethereum/common"
)

// Types correspondant au smart contract

// WalletInfo représente les informations d'un wallet
type WalletInfo struct {
	WalletAddress   common.Address
	AvailableCredits *big.Int
	LockedCredits    *big.Int
	KycStatus       string
	IsActive        bool
	DailyLimit      *big.Int
	MonthlyLimit    *big.Int
	TotalWithdrawn  *big.Int
}

// Transaction représente une transaction blockchain
type Transaction struct {
	ID              common.Hash
	From            common.Address
	To              common.Address
	Amount          *big.Int
	Fee             *big.Int
	TransactionType string
	Status          string
	Description     string
	Timestamp       uint64
	ReferenceLedgerId common.Hash
}

// WalletBalance représente le solde d'un wallet
type WalletBalance struct {
	Available *big.Int
	Locked    *big.Int
	Total     *big.Int
	KycStatus string
}

// WalletStats représente les statistiques d'un wallet
type WalletStats struct {
	Wallet              WalletInfo
	TodaySent           *big.Int
	TodayReceived       *big.Int
	MonthlySent         *big.Int
	MonthlyReceived     *big.Int
	AllTimeTransactions uint64
	AllTimeSent         *big.Int
	AllTimeReceived     *big.Int
	AllTimeFees         *big.Int
}

// WithdrawalRequest représente une demande de retrait
type WithdrawalRequest struct {
	ID            common.Hash
	WalletAddress common.Address
	Amount        *big.Int
	Fee           *big.Int
	NetAmount     *big.Int
	Status        string
	CreatedAt     uint64
}

// AuditReport représente un rapport d'audit
type AuditReport struct {
	Summary struct {
		TotalTransactions     uint64
		TotalCreditsSent      *big.Int
		TotalCreditsReceived  *big.Int
		TotalFees             *big.Int
	}
	Transactions []TransactionDetail
}

// TransactionDetail représente le détail d'une transaction pour l'audit
type TransactionDetail struct {
	ID              common.Hash
	TransactionType string
	Amount          *big.Int
	Fee             *big.Int
	Direction       string
	Timestamp       uint64
	LedgerHash      common.Hash
}