package ethereum

import (
	"context"
	"crypto/ecdsa"
	"fmt"
	"math/big"
	"strings"
	"time"

	"blockchain-service/internal/config"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
)

// ContractABI est l'ABI complet du smart contract EduMateWallet
const ContractABI = `[
	{
		"inputs": [{"internalType": "string", "name": "userId", "type": "string"}],
		"name": "createWallet",
		"outputs": [{"internalType": "address", "name": "", "type": "address"}],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [{"internalType": "string", "name": "userId", "type": "string"}],
		"name": "getWalletByUser",
		"outputs": [{"internalType": "address", "name": "", "type": "address"}],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [{"internalType": "address", "name": "walletAddress", "type": "address"}],
		"name": "getUserByWallet",
		"outputs": [{"internalType": "string", "name": "", "type": "string"}],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [{"internalType": "address", "name": "walletAddress", "type": "address"}],
		"name": "getBalance",
		"outputs": [
			{"internalType": "uint256", "name": "available", "type": "uint256"},
			{"internalType": "uint256", "name": "locked", "type": "uint256"},
			{"internalType": "uint256", "name": "total", "type": "uint256"},
			{"internalType": "string", "name": "kycStatus", "type": "string"}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [{"internalType": "address", "name": "walletAddress", "type": "address"}],
		"name": "getStats",
		"outputs": [
			{"components": [
				{"internalType": "address", "name": "walletAddress", "type": "address"},
				{"internalType": "uint256", "name": "availableCredits", "type": "uint256"},
				{"internalType": "uint256", "name": "lockedCredits", "type": "uint256"},
				{"internalType": "string", "name": "kycStatus", "type": "string"},
				{"internalType": "bool", "name": "isActive", "type": "bool"},
				{"internalType": "uint256", "name": "dailyLimit", "type": "uint256"},
				{"internalType": "uint256", "name": "monthlyLimit", "type": "uint256"},
				{"internalType": "uint256", "name": "totalWithdrawn", "type": "uint256"}
			], "internalType": "struct EduMateWallet.WalletInfo", "name": "", "type": "tuple"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"},
			{"internalType": "uint256", "name": "", "type": "uint256"}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{"internalType": "address", "name": "from", "type": "address"},
			{"internalType": "address", "name": "to", "type": "address"},
			{"internalType": "uint256", "name": "amount", "type": "uint256"},
			{"internalType": "string", "name": "description", "type": "string"},
			{"internalType": "string", "name": "transactionType", "type": "string"}
		],
		"name": "transfer",
		"outputs": [{"internalType": "bytes32", "name": "", "type": "bytes32"}],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{"internalType": "address", "name": "walletAddress", "type": "address"},
			{"internalType": "uint256", "name": "amount", "type": "uint256"},
			{"internalType": "string", "name": "bankDetailsJSON", "type": "string"}
		],
		"name": "requestWithdrawal",
		"outputs": [{"internalType": "bytes32", "name": "", "type": "bytes32"}],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{"internalType": "address", "name": "walletAddress", "type": "address"},
			{"internalType": "uint256", "name": "page", "type": "uint256"},
			{"internalType": "uint256", "name": "limit", "type": "uint256"},
			{"internalType": "uint256", "name": "startDate", "type": "uint256"},
			{"internalType": "uint256", "name": "endDate", "type": "uint256"}
		],
		"name": "getTransactionHistory",
		"outputs": [
			{"components": [
				{"internalType": "bytes32", "name": "id", "type": "bytes32"},
				{"internalType": "address", "name": "from", "type": "address"},
				{"internalType": "address", "name": "to", "type": "address"},
				{"internalType": "uint256", "name": "amount", "type": "uint256"},
				{"internalType": "uint256", "name": "fee", "type": "uint256"},
				{"internalType": "string", "name": "transactionType", "type": "string"},
				{"internalType": "string", "name": "status", "type": "string"},
				{"internalType": "string", "name": "description", "type": "string"},
				{"internalType": "uint256", "name": "timestamp", "type": "uint256"},
				{"internalType": "bytes32", "name": "referenceLedgerId", "type": "bytes32"}
			], "internalType": "struct EduMateWallet.Transaction[]", "name": "", "type": "tuple[]"},
			{"internalType": "uint256", "name": "", "type": "uint256"}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	}
]`

type Client struct {
	ethClient      *ethclient.Client
	chainID        *big.Int
	privateKey     *ecdsa.PrivateKey
	fromAddress    common.Address
	contract       *bind.BoundContract
	contractABI    abi.ABI
	contractAddress common.Address
}

func NewClient(cfg *config.Config) (*Client, error) {
	// Connexion au nœud Ethereum
	client, err := ethclient.Dial(cfg.Ethereum.RPCURL)
	if err != nil {
		return nil, fmt.Errorf("échec connexion Ethereum: %w", err)
	}

	// Obtenir le chain ID
	chainID, err := client.ChainID(context.Background())
	if err != nil {
		return nil, fmt.Errorf("échec récupération chain ID: %w", err)
	}

	// Charger la clé privée
	rawKey := strings.TrimSpace(cfg.Ethereum.PrivateKey)
	rawKey = strings.TrimPrefix(rawKey, "0x")

	if rawKey == "" {
		return nil, fmt.Errorf("ETH_PRIVATE_KEY est vide")
	}

	if len(rawKey) != 64 {
		return nil, fmt.Errorf("clé privée invalide: longueur %d, attendu 64", len(rawKey))
	}

	privateKey, err := crypto.HexToECDSA(rawKey)
	if err != nil {
		return nil, fmt.Errorf("clé privée invalide: %w", err)
	}

	// Récupérer l'adresse publique
	publicKey := privateKey.Public()
	publicKeyECDSA, ok := publicKey.(*ecdsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("échec conversion clé publique")
	}

	fromAddress := crypto.PubkeyToAddress(*publicKeyECDSA)

	// Charger l'ABI du contrat
	contractABI, err := abi.JSON(strings.NewReader(ContractABI))
	if err != nil {
		return nil, fmt.Errorf("échec chargement ABI: %w", err)
	}

	// Adresse du contrat déployé
	contractAddress := common.HexToAddress(cfg.Ethereum.ContractAddress)

	// Créer le contrat lié
	contract := bind.NewBoundContract(contractAddress, contractABI, client, client, client)

	return &Client{
		ethClient:      client,
		chainID:        chainID,
		privateKey:     privateKey,
		fromAddress:    fromAddress,
		contract:       contract,
		contractABI:    contractABI,
		contractAddress: contractAddress,
	}, nil
}

// CreateWallet crée un wallet pour un userId
func (c *Client) CreateWallet(userID string) (common.Hash, error) {
	auth, err := bind.NewKeyedTransactorWithChainID(c.privateKey, c.chainID)
	if err != nil {
		return common.Hash{}, fmt.Errorf("échec création transacteur: %w", err)
	}

	// Appeler la fonction createWallet du contrat
	tx, err := c.contract.Transact(auth, "createWallet", userID)
	if err != nil {
		return common.Hash{}, fmt.Errorf("échec création wallet: %w", err)
	}

	return tx.Hash(), nil
}

// GetWalletByUser récupère l'adresse d'un wallet par userId
func (c *Client) GetWalletByUser(userID string) (common.Address, error) {
	var walletAddress common.Address

	err := c.contract.Call(&bind.CallOpts{}, &walletAddress, "getWalletByUser", userID)
	if err != nil {
		return common.Address{}, fmt.Errorf("échec récupération wallet: %w", err)
	}

	return walletAddress, nil
}

// GetUserByWallet récupère le userId par adresse de wallet
func (c *Client) GetUserByWallet(walletAddress common.Address) (string, error) {
	var userID string

	err := c.contract.Call(&bind.CallOpts{}, &userID, "getUserByWallet", walletAddress)
	if err != nil {
		return "", fmt.Errorf("échec récupération utilisateur: %w", err)
	}

	return userID, nil
}

// GetBalance récupère le solde d'un wallet
func (c *Client) GetBalance(walletAddress common.Address) (*WalletBalance, error) {
	var result struct {
		Available *big.Int
		Locked    *big.Int
		Total     *big.Int
		KycStatus string
	}

	err := c.contract.Call(&bind.CallOpts{}, &result, "getBalance", walletAddress)
	if err != nil {
		return nil, fmt.Errorf("échec appel getBalance: %w", err)
	}

	return &WalletBalance{
		Available:  result.Available,
		Locked:     result.Locked,
		Total:      result.Total,
		KycStatus:  result.KycStatus,
	}, nil
}

// GetStats récupère les statistiques d'un wallet
func (c *Client) GetStats(walletAddress common.Address) (*WalletStats, error) {
	var result struct {
		Wallet               WalletInfo
		TodaySent           *big.Int
		TodayReceived       *big.Int
		MonthlySent         *big.Int
		MonthlyReceived     *big.Int
		AllTimeTransactions uint64
		AllTimeSent         *big.Int
		AllTimeReceived     *big.Int
		AllTimeFees         *big.Int
	}

	err := c.contract.Call(&bind.CallOpts{}, &result, "getStats", walletAddress)
	if err != nil {
		return nil, fmt.Errorf("échec récupération stats: %w", err)
	}

	return &WalletStats{
		Wallet:               result.Wallet,
		TodaySent:           result.TodaySent,
		TodayReceived:       result.TodayReceived,
		MonthlySent:         result.MonthlySent,
		MonthlyReceived:     result.MonthlyReceived,
		AllTimeTransactions: result.AllTimeTransactions,
		AllTimeSent:         result.AllTimeSent,
		AllTimeReceived:     result.AllTimeReceived,
		AllTimeFees:         result.AllTimeFees,
	}, nil
}

// Transfer effectue un transfert
func (c *Client) Transfer(from, to common.Address, amount *big.Int, description, transactionType string) (common.Hash, error) {
	auth, err := bind.NewKeyedTransactorWithChainID(c.privateKey, c.chainID)
	if err != nil {
		return common.Hash{}, fmt.Errorf("échec création transacteur: %w", err)
	}

	tx, err := c.contract.Transact(auth, "transfer", from, to, amount, description, transactionType)
	if err != nil {
		return common.Hash{}, fmt.Errorf("échec envoi transaction: %w", err)
	}

	return tx.Hash(), nil
}

// RequestWithdrawal crée une demande de retrait
func (c *Client) RequestWithdrawal(walletAddress common.Address, amount *big.Int, bankDetailsJSON string) (common.Hash, error) {
	auth, err := bind.NewKeyedTransactorWithChainID(c.privateKey, c.chainID)
	if err != nil {
		return common.Hash{}, fmt.Errorf("échec création transacteur: %w", err)
	}

	tx, err := c.contract.Transact(auth, "requestWithdrawal", walletAddress, amount, bankDetailsJSON)
	if err != nil {
		return common.Hash{}, fmt.Errorf("échec demande retrait: %w", err)
	}

	return tx.Hash(), nil
}

// GetTransactionHistory récupère l'historique des transactions
func (c *Client) GetTransactionHistory(
	walletAddress common.Address,
	page, limit uint64,
	startDate, endDate uint64,
) ([]Transaction, uint64, error) {
	var transactions []Transaction
	var total uint64

	err := c.contract.Call(&bind.CallOpts{}, []interface{}{&transactions, &total}, 
		"getTransactionHistory", walletAddress, page, limit, startDate, endDate)
	if err != nil {
		return nil, 0, fmt.Errorf("échec récupération historique: %w", err)
	}

	return transactions, total, nil
}

// WaitForTransactionReceipt attend la confirmation d'une transaction
func (c *Client) WaitForTransactionReceipt(txHash common.Hash) (*types.Receipt, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()

	for {
		receipt, err := c.ethClient.TransactionReceipt(ctx, txHash)
		if err != nil {
			if err == ethereum.NotFound {
				select {
				case <-time.After(2 * time.Second):
					continue
				case <-ctx.Done():
					return nil, fmt.Errorf("timeout attente confirmation: %w", ctx.Err())
				}
			}
			return nil, fmt.Errorf("échec récupération receipt: %w", err)
		}

		if receipt.Status == types.ReceiptStatusSuccessful {
			return receipt, nil
		} else {
			return nil, fmt.Errorf("transaction échouée: %v", receipt.Status)
		}
	}
}

// GetChainID récupère l'ID de la chaine
func (c *Client) GetChainID() (*big.Int, error) {
	return c.chainID, nil
}

// Close ferme la connexion
func (c *Client) Close() {
	if c.ethClient != nil {
		c.ethClient.Close()
	}
}

// Keccak256Hash fonction helper
func Keccak256Hash(data []byte) common.Hash {
	return crypto.Keccak256Hash(data)
}

// EthToWei convertit des ETH en Wei
func EthToWei(ethAmount float64) *big.Int {
	wei := new(big.Float).Mul(big.NewFloat(ethAmount), big.NewFloat(1e18))
	weiInt, _ := wei.Int(nil)
	return weiInt
}

// WeiToEth convertit des Wei en ETH
func WeiToEth(wei *big.Int) float64 {
	if wei == nil {
		return 0
	}
	weiFloat := new(big.Float).SetInt(wei)
	eth := new(big.Float).Quo(weiFloat, big.NewFloat(1e18))
	result, _ := eth.Float64()
	return result
}

// StringToAddress convertit une string en adresse Ethereum
func StringToAddress(address string) (common.Address, error) {
	if !common.IsHexAddress(address) {
		return common.Address{}, fmt.Errorf("adresse Ethereum invalide")
	}
	return common.HexToAddress(address), nil
}