package service

import (
	"fmt"
	"strings"

	"blockchain-service/internal/blockchain/ethereum"

	"github.com/ethereum/go-ethereum/common"
)

// WalletService gère les wallets sans base de données
type WalletService struct {
	ethClient *ethereum.Client
}

// NewWalletService crée un nouveau service
func NewWalletService(ethClient *ethereum.Client) *WalletService {
	return &WalletService{
		ethClient: ethClient,
	}
}

// GetOrCreateWallet retourne ou crée un wallet pour un utilisateur
func (s *WalletService) GetOrCreateWallet(userID string) (common.Address, error) {
	// Nettoyer l'ID utilisateur
	userID = CleanUserID(userID)
	
	// 1. Essayer de récupérer l'adresse depuis le smart contract
	walletAddress, err := s.GetWalletAddressForUser(userID)
	if err == nil {
		// Le wallet existe déjà, le retourner
		fmt.Printf("✅ Wallet trouvé pour %s: %s\n", userID, walletAddress.Hex())
		return walletAddress, nil
	}

	// 2. Si le wallet n'existe pas, le créer via le smart contract
	fmt.Printf("🆕 Création du wallet pour l'utilisateur %s\n", userID)
	
	// Appeler la fonction createWallet du smart contract
	txHash, err := s.ethClient.CreateWallet(userID)
	if err != nil {
		return common.Address{}, fmt.Errorf("échec création wallet sur blockchain: %w", err)
	}

	// Attendre la confirmation
	receipt, err := s.ethClient.WaitForTransactionReceipt(txHash)
	if err != nil {
		return common.Address{}, fmt.Errorf("échec confirmation création wallet: %w", err)
	}

	// Récupérer l'adresse créée (via l'algorithme déterministe)
	walletAddress = s.GenerateDeterministicAddress(userID)
	
	fmt.Printf("✅ Wallet créé pour %s: %s (tx: %s)\n", 
		userID, walletAddress.Hex(), receipt.TxHash.Hex())
	
	return walletAddress, nil
}

// GetWalletAddressForUser récupère l'adresse depuis le smart contract
func (s *WalletService) GetWalletAddressForUser(userID string) (common.Address, error) {
	userID = CleanUserID(userID)
	
	// Appeler la fonction getWalletByUser du smart contract
	address, err := s.ethClient.GetWalletByUser(userID)
	if err != nil {
		return common.Address{}, fmt.Errorf("wallet not found for user %s: %w", userID, err)
	}
	
	// Vérifier que l'adresse n'est pas 0x0
	if address == (common.Address{}) {
		return common.Address{}, fmt.Errorf("wallet not found for user %s", userID)
	}
	
	return address, nil
}

// GenerateDeterministicAddress génère la même adresse que le smart contract
func (s *WalletService) GenerateDeterministicAddress(userID string) common.Address {
	userID = CleanUserID(userID)
	// Même algorithme que dans le smart contract
	hash := ethereum.Keccak256Hash([]byte(userID))
	return common.BytesToAddress(hash.Bytes()[:20])
}

// GetUserFromWallet retourne l'userId associé à une adresse
func (s *WalletService) GetUserFromWallet(walletAddress common.Address) (string, error) {
	// Appeler la fonction getUserByWallet du smart contract
	userID, err := s.ethClient.GetUserByWallet(walletAddress)
	if err != nil {
		return "", fmt.Errorf("no user found for wallet %s: %w", walletAddress.Hex(), err)
	}
	
	return userID, nil
}

// CleanUserID nettoie le userID
func CleanUserID(userID string) string {
	// Retirer les éventuels espaces et guillemets
	userID = strings.TrimSpace(userID)
	userID = strings.Trim(userID, `"`)
	return userID
}