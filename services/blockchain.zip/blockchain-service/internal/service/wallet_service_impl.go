package service

import (
	"fmt"
	"math/big"
	"time"

	"blockchain-service/internal/blockchain"
	"blockchain-service/internal/domain"

	"github.com/ethereum/go-ethereum/common"
)

type WalletService struct {
	reader blockchain.BlockchainReader
	writer blockchain.BlockchainWriter
}

func NewWalletService(reader blockchain.BlockchainReader, writer blockchain.BlockchainWriter) *WalletService {
	return &WalletService{
		reader: reader,
		writer: writer,
	}
}

func (s *WalletService) GetWalletBalance(userID string) (*domain.WalletBalance, error) {
	// Obtenir l'adresse Ethereum pour cet utilisateur
	address, err := GetWalletAddressForUser(userID)
	if err != nil {
		return nil, fmt.Errorf("échec récupération adresse: %w", err)
	}

	// Récupérer le solde depuis la blockchain
	balance, err := s.reader.GetBalance(address)
	if err != nil {
		return nil, fmt.Errorf("échec récupération solde: %w", err)
	}

	// Convertir en domaine
	userInfo := domain.UserInfo{
		ID:        userID,
		FirstName: "Utilisateur", // À récupérer depuis un service externe
		LastName:  "",
		Email:     "user@example.com",
		Role:      "user",
	}

	walletInfo := domain.WalletInfo{
		Available:     float64(balance.Available.Int64()) / 1e18,
		Locked:        float64(balance.Locked.Int64()) / 1e18,
		Total:         float64(balance.Total.Int64()) / 1e18,
		WalletAddress: address.Hex(),
		KycStatus:     balance.KycStatus,
	}

	return &domain.WalletBalance{
		User:   userInfo,
		Wallet: walletInfo,
	}, nil
}

func (s *WalletService) TransferCredits(
	fromUserID string,
	toWalletAddress string,
	amount float64,
	description string,
	metadata map[string]interface{},
) (*domain.Transaction, error) {
	// Obtenir l'adresse de l'expéditeur
	fromAddress, err := GetWalletAddressForUser(fromUserID)
	if err != nil {
		return nil, fmt.Errorf("échec récupération adresse expéditeur: %w", err)
	}

	// Convertir l'adresse du destinataire
	if !common.IsHexAddress(toWalletAddress) {
		return nil, fmt.Errorf("adresse destinataire invalide")
	}
	toAddress := common.HexToAddress(toWalletAddress)

	// Convertir le montant en wei
	amountWei := int64(amount * 1e18)

	// Exécuter le transfert
	txHash, err := s.writer.Transfer(
		fromAddress,
		toAddress,
		big.NewInt(amountWei),
		description,
		"EXCHANGE_SERVICE",
	)
	if err != nil {
		return nil, fmt.Errorf("échec transfert: %w", err)
	}

	// Créer la transaction de domaine
	transaction := &domain.Transaction{
		ID:              txHash.Hex(),
		FromWalletID:    fromAddress.Hex(),
		ToWalletID:      toAddress.Hex(),
		Amount:          amount,
		Fee:             amount * 0.01, // 1% de frais
		TransactionType: "EXCHANGE_SERVICE",
		Status:          "completed",
		Description:     description,
		Metadata:        metadata,
		CreatedAt:       time.Now(),
	}

	return transaction, nil
}

func (s *WalletService) GetWalletHistory(
	userID string,
	page, limit int,
	startDate, endDate string,
	transactionType string,
) (*domain.TransactionHistory, error) {
	address, err := GetWalletAddressForUser(userID)
	if err != nil {
		return nil, fmt.Errorf("échec récupération adresse: %w", err)
	}

	// Convertir les dates en timestamp
	var startTimestamp, endTimestamp uint64
	// ... conversion des dates

	// Récupérer l'historique
	transactions, total, err := s.reader.GetTransactionHistory(
		address,
		uint64(page-1),
		uint64(limit),
		startTimestamp,
		endTimestamp,
	)
	if err != nil {
		return nil, fmt.Errorf("échec récupération historique: %w", err)
	}

	// Convertir en transactions de domaine
	domainTransactions := make([]domain.Transaction, len(transactions))
	for i, tx := range transactions {
		domainTransactions[i] = *domain.ToDomainTransaction(
			tx.ID,
			tx.From,
			tx.To,
			tx.Amount,
			tx.Fee,
			tx.TransactionType,
			tx.Status,
			tx.Description,
			tx.Timestamp,
		)
	}

	totalPages := (int(total) + limit - 1) / limit

	return &domain.TransactionHistory{
		Transactions: domainTransactions,
		Total:        int64(total),
		Page:         page,
		TotalPages:   totalPages,
	}, nil
}

func (s *WalletService) GetWalletStats(userID string) (*domain.WalletStats, error) {
	address, err := GetWalletAddressForUser(userID)
	if err != nil {
		return nil, fmt.Errorf("échec récupération adresse: %w", err)
	}

	stats, err := s.reader.GetStats(address)
	if err != nil {
		return nil, fmt.Errorf("échec récupération stats: %w", err)
	}

	return &domain.WalletStats{
		Wallet: domain.WalletStatsInfo{
			Available: float64(stats.Wallet.AvailableCredits.Int64()) / 1e18,
			Locked:    float64(stats.Wallet.LockedCredits.Int64()) / 1e18,
			Total:     float64(stats.Wallet.AvailableCredits.Int64()+stats.Wallet.LockedCredits.Int64()) / 1e18,
			Address:   address.Hex(),
			KycStatus: stats.Wallet.KycStatus,
		},
		Today: domain.PeriodStats{
			Sent:     float64(stats.TodaySent.Int64()) / 1e18,
			Received: float64(stats.TodayReceived.Int64()) / 1e18,
		},
		Monthly: domain.PeriodStats{
			Sent:     float64(stats.MonthlySent.Int64()) / 1e18,
			Received: float64(stats.MonthlyReceived.Int64()) / 1e18,
		},
		AllTime: domain.AllTimeStats{
			Transactions: int64(stats.AllTimeTransactions),
			Sent:         float64(stats.AllTimeSent.Int64()) / 1e18,
			Received:     float64(stats.AllTimeReceived.Int64()) / 1e18,
			Fees:         float64(stats.AllTimeFees.Int64()) / 1e18,
		},
	}, nil
}