package domain

import (
	"math/big"
	"time"

	"github.com/ethereum/go-ethereum/common"
)

type Transaction struct {
	ID              string                 `json:"id"`
	FromWalletID    string                 `json:"fromWalletId,omitempty"`
	ToWalletID      string                 `json:"toWalletId"`
	Amount          float64                `json:"amount"`
	Fee             float64                `json:"fee"`
	TransactionType string                 `json:"transactionType"`
	Status          string                 `json:"status"` // "pending", "completed", "failed", "cancelled"
	Description     string                 `json:"description,omitempty"`
	Metadata        map[string]interface{} `json:"metadata"`
	CreatedAt       time.Time              `json:"createdAt"`
	
	// Relations optionnelles
	FromWallet     *Wallet `json:"fromWallet,omitempty"`
	ToWallet       *Wallet `json:"toWallet,omitempty"`
	LedgerBlock    *LedgerBlock `json:"ledgerBlock,omitempty"`
}

type LedgerBlock struct {
	ID        int64     `json:"id"`
	Hash      string    `json:"hash"`
	Timestamp time.Time `json:"timestamp"`
}

type TransactionHistory struct {
	Transactions []Transaction `json:"transactions"`
	Total        int64         `json:"total"`
	Page         int           `json:"page"`
	TotalPages   int           `json:"totalPages"`
}

func ToDomainTransaction(
	txHash common.Hash,
	from, to common.Address,
	amount, fee *big.Int,
	txType, status, description string,
	timestamp uint64,
) *Transaction {
	return &Transaction{
		ID:              txHash.Hex(),
		FromWalletID:    from.Hex(),
		ToWalletID:      to.Hex(),
		Amount:          float64(amount.Int64()) / 1e18,
		Fee:             float64(fee.Int64()) / 1e18,
		TransactionType: txType,
		Status:          status,
		Description:     description,
		Metadata:        make(map[string]interface{}),
		CreatedAt:       time.Unix(int64(timestamp), 0),
	}
}