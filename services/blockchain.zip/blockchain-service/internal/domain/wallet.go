package domain

import (
	"math/big"
	"time"

	"github.com/ethereum/go-ethereum/common"
)

type Wallet struct {
	ID              string    `json:"id"`
	UserID          string    `json:"userId"`
	WalletAddress   string    `json:"walletAddress"`
	AvailableCredits float64   `json:"available"`
	LockedCredits   float64   `json:"locked"`
	TotalCredits    float64   `json:"total"`
	KycStatus       string    `json:"kycStatus"`
	IsActive        bool      `json:"isActive"`
	DailyLimit      float64   `json:"dailyLimit"`
	MonthlyLimit    float64   `json:"monthlyLimit"`
	TotalWithdrawn  float64   `json:"totalWithdrawn"`
	CreatedAt       time.Time `json:"createdAt"`
	UpdatedAt       time.Time `json:"updatedAt"`
}

type WalletBalance struct {
	User   UserInfo   `json:"user"`
	Wallet WalletInfo `json:"wallet"`
}

type UserInfo struct {
	ID        string `json:"id"`
	FirstName string `json:"firstName"`
	LastName  string `json:"lastName"`
	Email     string `json:"email"`
	Role      string `json:"role"`
}

type WalletInfo struct {
	Available     float64 `json:"available"`
	Locked        float64 `json:"locked"`
	Total         float64 `json:"total"`
	WalletAddress string  `json:"walletAddress"`
	KycStatus     string  `json:"kycStatus"`
}

func ToDomainWallet(ethAddress common.Address, available, locked *big.Int, kycStatus string) *Wallet {
	avail := float64(available.Int64()) / 1e18
	lock := float64(locked.Int64()) / 1e18

	return &Wallet{
		WalletAddress:   ethAddress.Hex(),
		AvailableCredits: avail,
		LockedCredits:   lock,
		TotalCredits:    avail + lock,
		KycStatus:       kycStatus,
		IsActive:        true,
		CreatedAt:       time.Now(),
		UpdatedAt:       time.Now(),
	}
}