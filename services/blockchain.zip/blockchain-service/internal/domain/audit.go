package domain

import "time"

type AuditReport struct {
	Summary      AuditSummary `json:"summary"`
	Transactions []AuditTransaction `json:"transactions"`
}

type AuditSummary struct {
	TotalTransactions     int64     `json:"totalTransactions"`
	TotalCreditsSent      float64   `json:"totalCreditsSent"`
	TotalCreditsReceived  float64   `json:"totalCreditsReceived"`
	TotalFees             float64   `json:"totalFees"`
	Period                AuditPeriod `json:"period"`
}

type AuditPeriod struct {
	StartDate string `json:"startDate"`
	EndDate   string `json:"endDate"`
}

type AuditTransaction struct {
	ID        string    `json:"id"`
	Type      string    `json:"type"`
	Amount    float64   `json:"amount"`
	Fee       float64   `json:"fee"`
	Direction string    `json:"direction"` // "OUTGOING" or "INCOMING"
	Timestamp time.Time `json:"timestamp"`
	LedgerHash string   `json:"ledgerHash"`
}