package domain

type WalletStats struct {
	Wallet  WalletStatsInfo `json:"wallet"`
	Today   PeriodStats     `json:"today"`
	Monthly PeriodStats     `json:"monthly"`
	AllTime AllTimeStats    `json:"allTime"`
}

type WalletStatsInfo struct {
	Available  float64 `json:"available"`
	Locked     float64 `json:"locked"`
	Total      float64 `json:"total"`
	Address    string  `json:"address"`
	KycStatus  string  `json:"kycStatus"`
}

type PeriodStats struct {
	Sent     float64 `json:"sent"`
	Received float64 `json:"received"`
}

type AllTimeStats struct {
	Transactions int64   `json:"transactions"`
	Sent         float64 `json:"sent"`
	Received     float64 `json:"received"`
	Fees         float64 `json:"fees"`
}