package config

import (
	"fmt"
	"log"
	"os"
	"strconv"
)

// Config holds all configuration for the blockchain service
type Config struct {
	// Server configuration
	Port    string
	Env     string
	LogLevel string

	// Ethereum/Blockchain configuration
	Ethereum EthereumConfig

	// Database configuration
	Redis RedisConfig

	// Security configuration
	JWT JWTConfig

	// Internal service authentication
	InternalServiceToken string
}

// EthereumConfig holds Ethereum-specific configuration
type EthereumConfig struct {
	RPCURL          string
	PrivateKey      string
	ContractAddress string
	ChainID         int64
	GasLimit        uint64
}

// RedisConfig holds Redis configuration
type RedisConfig struct {
	URL      string
	Enabled  bool
	MaxRetry int
	PoolSize int
}

// JWTConfig holds JWT-specific configuration
type JWTConfig struct {
	Secret    string
	ExpiresIn int // in hours
}

// LoadConfig loads configuration from environment variables
func LoadConfig() (*Config, error) {
	cfg := &Config{
		Port:     getEnv("PORT", "3003"),
		Env:      getEnv("ENVIRONMENT", "development"),
		LogLevel: getEnv("LOG_LEVEL", "info"),

		Ethereum: EthereumConfig{
			RPCURL:          getEnv("ETH_RPC_URL", "http://localhost:8545"),
			PrivateKey:      getEnv("ETH_PRIVATE_KEY", ""),
			ContractAddress: getEnv("CONTRACT_ADDRESS", ""),
			ChainID:         int64(getEnvInt("ETH_CHAIN_ID", 1337)),
			GasLimit:        getEnvUint64("GAS_LIMIT", 300000),
		},

		Redis: RedisConfig{
			URL:      getEnv("REDIS_URL", "redis://localhost:6379"),
			Enabled:  getEnvBool("REDIS_ENABLED", true),
			MaxRetry: getEnvInt("REDIS_MAX_RETRY", 3),
			PoolSize: getEnvInt("REDIS_POOL_SIZE", 10),
		},

		JWT: JWTConfig{
			Secret:    getEnv("JWT_SECRET", "aB3dE5fG7hI9jK2lM0nPqR1sT4uVwX6yZ"),
			ExpiresIn: getEnvInt("JWT_EXPIRES_IN", 24),
		},

		InternalServiceToken: getEnv("INTERNAL_SERVICE_TOKEN", ""),
	}

	// Validate critical configuration
	if err := cfg.Validate(); err != nil {
		return nil, err
	}

	return cfg, nil
}

// Validate checks if the configuration is valid
func (c *Config) Validate() error {
	if c.Ethereum.PrivateKey == "" {
		// Pour le développement, on peut générer une clé par défaut
		if c.IsDevelopment() {
			log.Println("⚠️  ETH_PRIVATE_KEY non définie, utilisation d'une clé par défaut pour le développement")
			c.Ethereum.PrivateKey = "ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
		} else {
			return fmt.Errorf("ETH_PRIVATE_KEY est requis en environnement de production")
		}
	}

	// Valider la longueur de la clé privée
	keyWithoutPrefix := c.Ethereum.PrivateKey
	if len(keyWithoutPrefix) > 2 && keyWithoutPrefix[:2] == "0x" {
		keyWithoutPrefix = keyWithoutPrefix[2:]
	}
	if len(keyWithoutPrefix) != 64 {
		return fmt.Errorf("ETH_PRIVATE_KEY invalide: longueur %d, besoin de 64 caractères hexadécimaux", len(keyWithoutPrefix))
	}

	if c.Ethereum.ContractAddress == "" && c.IsProduction() {
		return fmt.Errorf("CONTRACT_ADDRESS est requis en environnement de production")
	}

	if c.JWT.Secret == "aB3dE5fG7hI9jK2lM0nPqR1sT4uVwX6yZ" && c.IsProduction() {
		return fmt.Errorf("JWT_SECRET ne doit pas être la valeur par défaut en production")
	}

	return nil
}

// IsDevelopment returns true if the environment is development
func (c *Config) IsDevelopment() bool {
	return c.Env == "development" || c.Env == "dev"
}

// IsProduction returns true if the environment is production
func (c *Config) IsProduction() bool {
	return c.Env == "production" || c.Env == "prod"
}

// getEnv retrieves an environment variable with a default value
func getEnv(key string, defaultVal string) string {
	if val, exists := os.LookupEnv(key); exists {
		return val
	}
	return defaultVal
}

// getEnvInt retrieves an integer environment variable with a default value
func getEnvInt(key string, defaultVal int) int {
	if val, exists := os.LookupEnv(key); exists {
		if intVal, err := strconv.Atoi(val); err == nil {
			return intVal
		}
		log.Printf("Warning: invalid integer value for %s, using default: %d\n", key, defaultVal)
	}
	return defaultVal
}

// getEnvUint64 retrieves a uint64 environment variable with a default value
func getEnvUint64(key string, defaultVal uint64) uint64 {
	if val, exists := os.LookupEnv(key); exists {
		if uintVal, err := strconv.ParseUint(val, 10, 64); err == nil {
			return uintVal
		}
		log.Printf("Warning: invalid uint64 value for %s, using default: %d\n", key, defaultVal)
	}
	return defaultVal
}

// getEnvBool retrieves a boolean environment variable with a default value
func getEnvBool(key string, defaultVal bool) bool {
	if val, exists := os.LookupEnv(key); exists {
		if boolVal, err := strconv.ParseBool(val); err == nil {
			return boolVal
		}
		log.Printf("Warning: invalid boolean value for %s, using default: %v\n", key, defaultVal)
	}
	return defaultVal
}