package handlers

import (
	"net/http"
	"strconv"
)

// getQueryParamUint récupère un paramètre de requête uint avec valeur par défaut
func getQueryParamUint(r *http.Request, key string, defaultValue uint64) uint64 {
	valueStr := r.URL.Query().Get(key)
	if valueStr == "" {
		return defaultValue
	}

	value, err := strconv.ParseUint(valueStr, 10, 64)
	if err != nil {
		return defaultValue
	}

	return value
}
