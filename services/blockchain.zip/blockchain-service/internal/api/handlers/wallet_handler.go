package handlers

import (
	"encoding/json"
	"fmt"
	"math/big"
	"net/http"
	"time"

	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/config"
	"blockchain-service/internal/service"
)

// WalletHandler gère les opérations de wallet
type WalletHandler struct {
	ethClient     *ethereum.Client
	config        *config.Config
	walletService *service.WalletService
}

// NewWalletHandler crée un nouveau handler
func NewWalletHandler(ethClient *ethereum.Client, cfg *config.Config) *WalletHandler {
	walletService := service.NewWalletService(ethClient)
	return &WalletHandler{
		ethClient:     ethClient,
		config:        cfg,
		walletService: walletService,
	}
}

// GetBalance récupère le solde
func (h *WalletHandler) GetBalance(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	paramUserID := r.URL.Query().Get("userId")
	if paramUserID == "" {
		respondWithError(w, http.StatusBadRequest, "userId requis")
		return
	}

	if userID != paramUserID {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé")
		return
	}

	fmt.Printf("🔍 Récupération du wallet pour l'utilisateur: %s\n", paramUserID)

	// Obtenir ou créer le wallet (automatiquement)
	walletAddress, err := h.walletService.GetOrCreateWallet(paramUserID)
	if err != nil {
		fmt.Printf("❌ Erreur récupération wallet: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération wallet: "+err.Error())
		return
	}

	fmt.Printf("✅ Wallet trouvé/créé: %s\n", walletAddress.Hex())

	// Récupérer le solde
	balance, err := h.ethClient.GetBalance(walletAddress)
	if err != nil {
		fmt.Printf("❌ Erreur récupération solde: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération solde: "+err.Error())
		return
	}

	// Formater la réponse
	responseData := map[string]interface{}{
		"user": map[string]interface{}{
			"id":        paramUserID,
			"firstName": "Utilisateur",
			"lastName":  "",
			"email":     "user@example.com",
			"role":      "user",
		},
		"wallet": map[string]interface{}{
			"available":     ethereum.WeiToEth(balance.Available),
			"locked":        ethereum.WeiToEth(balance.Locked),
			"total":         ethereum.WeiToEth(balance.Total),
			"walletAddress": walletAddress.Hex(),
			"kycStatus":     balance.KycStatus,
		},
	}

	fmt.Printf("✅ Solde récupéré avec succès pour %s\n", paramUserID)
	respondWithJSON(w, http.StatusOK, true, "Solde récupéré avec succès", responseData)
}

// CreateWallet crée un nouveau wallet
func (h *WalletHandler) CreateWallet(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	var request struct {
		UserID string `json:"userId"`
	}

	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		respondWithError(w, http.StatusBadRequest, "Body invalide")
		return
	}

	if request.UserID == "" {
		respondWithError(w, http.StatusBadRequest, "userId requis")
		return
	}

	if userID != request.UserID {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé")
		return
	}

	fmt.Printf("🆕 Création manuelle du wallet pour: %s\n", request.UserID)

	// Créer le wallet
	walletAddress, err := h.walletService.GetOrCreateWallet(request.UserID)
	if err != nil {
		fmt.Printf("❌ Erreur création wallet: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur création wallet: "+err.Error())
		return
	}

	responseData := map[string]interface{}{
		"userId":        request.UserID,
		"walletAddress": walletAddress.Hex(),
		"createdAt":     time.Now().Format(time.RFC3339),
	}

	fmt.Printf("✅ Wallet créé avec succès: %s\n", walletAddress.Hex())
	respondWithJSON(w, http.StatusOK, true, "Wallet créé avec succès", responseData)
}

// GetStats récupère les statistiques
func (h *WalletHandler) GetStats(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	paramUserID := r.URL.Query().Get("userId")
	if paramUserID == "" {
		respondWithError(w, http.StatusBadRequest, "userId requis")
		return
	}

	if userID != paramUserID {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé")
		return
	}

	fmt.Printf("📊 Récupération des stats pour: %s\n", paramUserID)

	// Obtenir l'adresse
	walletAddress, err := h.walletService.GetOrCreateWallet(paramUserID)
	if err != nil {
		fmt.Printf("❌ Erreur récupération wallet pour stats: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération wallet: "+err.Error())
		return
	}

	// Récupérer les stats
	stats, err := h.ethClient.GetStats(walletAddress)
	if err != nil {
		fmt.Printf("❌ Erreur récupération stats: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération stats: "+err.Error())
		return
	}

	// Formater la réponse
	total := new(big.Int).Add(stats.Wallet.AvailableCredits, stats.Wallet.LockedCredits)
	responseData := map[string]interface{}{
		"wallet": map[string]interface{}{
			"available":  ethereum.WeiToEth(stats.Wallet.AvailableCredits),
			"locked":     ethereum.WeiToEth(stats.Wallet.LockedCredits),
			"total":      ethereum.WeiToEth(total),
			"address":    walletAddress.Hex(),
			"kycStatus":  stats.Wallet.KycStatus,
		},
		"today": map[string]interface{}{
			"sent":     ethereum.WeiToEth(stats.TodaySent),
			"received": ethereum.WeiToEth(stats.TodayReceived),
		},
		"monthly": map[string]interface{}{
			"sent":     ethereum.WeiToEth(stats.MonthlySent),
			"received": ethereum.WeiToEth(stats.MonthlyReceived),
		},
		"allTime": map[string]interface{}{
			"transactions": stats.AllTimeTransactions,
			"sent":         ethereum.WeiToEth(stats.AllTimeSent),
			"received":     ethereum.WeiToEth(stats.AllTimeReceived),
			"fees":         ethereum.WeiToEth(stats.AllTimeFees),
		},
	}

	fmt.Printf("✅ Stats récupérées avec succès pour %s\n", paramUserID)
	respondWithJSON(w, http.StatusOK, true, "Statistiques récupérées avec succès", responseData)
}

// GetHistory récupère l'historique des transactions
func (h *WalletHandler) GetHistory(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	paramUserID := r.URL.Query().Get("userId")
	if paramUserID == "" {
		respondWithError(w, http.StatusBadRequest, "userId requis")
		return
	}

	if userID != paramUserID {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé")
		return
	}

	fmt.Printf("📋 Récupération de l'historique pour: %s\n", paramUserID)

	// Obtenir l'adresse
	walletAddress, err := h.walletService.GetOrCreateWallet(paramUserID)
	if err != nil {
		fmt.Printf("❌ Erreur récupération wallet pour historique: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération wallet: "+err.Error())
		return
	}

	// Récupérer les paramètres de pagination
	page := getQueryParamUint(r, "page", 0)
	limit := getQueryParamUint(r, "limit", 50)

	// Récupérer l'historique
	transactions, total, err := h.ethClient.GetTransactionHistory(
		walletAddress,
		page,
		limit,
		0, // startDate
		0, // endDate
	)
	if err != nil {
		fmt.Printf("❌ Erreur récupération historique: %v\n", err)
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération historique: "+err.Error())
		return
	}

	// Formater les transactions
	formattedTransactions := make([]map[string]interface{}, len(transactions))
	for i, tx := range transactions {
		formattedTransactions[i] = map[string]interface{}{
			"id":              tx.ID.Hex(),
			"from":            tx.From.Hex(),
			"to":              tx.To.Hex(),
			"amount":          ethereum.WeiToEth(tx.Amount),
			"fee":             ethereum.WeiToEth(tx.Fee),
			"transactionType": tx.TransactionType,
			"status":          tx.Status,
			"description":     tx.Description,
			"timestamp":       time.Unix(int64(tx.Timestamp), 0).Format(time.RFC3339),
			"ledgerHash":      tx.ReferenceLedgerId.Hex(),
		}
	}

	responseData := map[string]interface{}{
		"transactions": formattedTransactions,
		"pagination": map[string]interface{}{
			"page":        page,
			"limit":       limit,
			"total":       total,
			"totalPages":  (total + limit - 1) / limit,
		},
	}

	fmt.Printf("✅ Historique récupéré: %d transactions\n", len(transactions))
	respondWithJSON(w, http.StatusOK, true, "Historique récupéré avec succès", responseData)
}

// RequestWithdrawal crée une demande de retrait
func (h *WalletHandler) RequestWithdrawal(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	var request struct {
		WalletID    string                 `json:"walletId"`
		Amount      float64                `json:"amount"`
		BankDetails map[string]interface{} `json:"bankDetails"`
	}

	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		respondWithError(w, http.StatusBadRequest, "Body invalide: "+err.Error())
		return
	}

	if request.WalletID == "" {
		respondWithError(w, http.StatusBadRequest, "walletId requis dans le body")
		return
	}

	// Obtenir l'adresse de l'utilisateur
	walletAddress, err := h.walletService.GetOrCreateWallet(userID)
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération wallet: "+err.Error())
		return
	}

	// Vérifier que le wallet appartient à l'utilisateur
	if walletAddress.Hex() != request.WalletID {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé à ce wallet")
		return
	}

	// Convertir le montant en wei
	amountWei := ethereum.EthToWei(request.Amount)

	// Convertir les détails bancaires en JSON
	bankDetailsJSON, err := json.Marshal(request.BankDetails)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Détails bancaires invalides")
		return
	}

	// Créer la demande de retrait sur la blockchain
	requestID, err := h.ethClient.RequestWithdrawal(walletAddress, amountWei, string(bankDetailsJSON))
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Erreur création demande de retrait: "+err.Error())
		return
	}

	// Attendre la confirmation
	receipt, err := h.ethClient.WaitForTransactionReceipt(requestID)
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Erreur confirmation demande: "+err.Error())
		return
	}

	responseData := map[string]interface{}{
		"id":        requestID.Hex(),
		"walletId":  walletAddress.Hex(),
		"amount":    request.Amount,
		"fee":       request.Amount * 0.01, // 1% de frais
		"netAmount": request.Amount * 0.99, // montant net
		"status":    "pending",
		"createdAt": time.Unix(int64(receipt.BlockNumber.Int64()), 0).Format(time.RFC3339),
	}

	respondWithJSON(w, http.StatusOK, true, "Demande de retrait créée avec succès", responseData)
}

// TestConnection teste la connexion à la blockchain
func (h *WalletHandler) TestConnection(w http.ResponseWriter, r *http.Request) {
	chainID, err := h.ethClient.GetChainID()
	if err != nil {
		respondWithJSON(w, http.StatusOK, false, "Connexion Ethereum échouée", map[string]interface{}{
			"error": err.Error(),
		})
		return
	}

	respondWithJSON(w, http.StatusOK, true, "Blockchain service fonctionne!", map[string]interface{}{
		"chainId":    chainID.String(),
		"timestamp":  time.Now().Format(time.RFC3339),
		"blockchain": "Ethereum",
		"status":     "connected",
	})
}

// GenerateAuditReport génère un rapport d'audit (simplifié)
func (h *WalletHandler) GenerateAuditReport(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	paramUserID := r.URL.Query().Get("userId")
	if paramUserID == "" {
		respondWithError(w, http.StatusBadRequest, "userId requis")
		return
	}

	if userID != paramUserID {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé")
		return
	}

	// Pour l'instant, retourner un rapport factice
	responseData := map[string]interface{}{
		"summary": map[string]interface{}{
			"totalTransactions":      0,
			"totalCreditsSent":       0,
			"totalCreditsReceived":   0,
			"totalFees":              0,
			"period": map[string]interface{}{
				"startDate": r.URL.Query().Get("startDate"),
				"endDate":   r.URL.Query().Get("endDate"),
			},
		},
		"transactions": []interface{}{},
	}

	respondWithJSON(w, http.StatusOK, true, "Rapport d'audit généré avec succès", responseData)
}