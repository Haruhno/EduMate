package handlers

import (
	"context"
	"net/http"
	"strings"

	"github.com/golang-jwt/jwt/v5"
)

// InternalServiceMiddleware vérifie le token du service interne
func InternalServiceMiddleware(internalToken string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Vérifier que le token n'est pas vide
			if internalToken == "" {
				respondWithError(w, http.StatusInternalServerError, "INTERNAL_SERVICE_TOKEN not configured")
				return
			}

			// Récupérer le header Authorization
			authHeader := r.Header.Get("Authorization")
			if authHeader == "" {
				respondWithError(w, http.StatusUnauthorized, "Token interne manquant")
				return
			}

			// Extraire le token (format: "Bearer <token>")
			tokenString := strings.TrimPrefix(authHeader, "Bearer ")
			if tokenString == authHeader {
				respondWithError(w, http.StatusUnauthorized, "Format de token invalide")
				return
			}

			// Vérifier que le token correspond au token configuré
			if tokenString != internalToken {
				respondWithError(w, http.StatusUnauthorized, "Token interne invalide")
				return
			}

			// Si tout est bon, continuer
			next.ServeHTTP(w, r)
		})
	}
}

func AuthMiddleware(jwtSecret string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			authHeader := r.Header.Get("Authorization")
			if authHeader == "" {
				respondWithError(w, http.StatusUnauthorized, "Token manquant")
				return
			}

			tokenString := strings.TrimPrefix(authHeader, "Bearer ")
			if tokenString == authHeader {
				respondWithError(w, http.StatusUnauthorized, "Format de token invalide")
				return
			}

			token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
				return []byte(jwtSecret), nil
			})

			if err != nil || !token.Valid {
				respondWithError(w, http.StatusUnauthorized, "Token invalide")
				return
			}

			claims, ok := token.Claims.(jwt.MapClaims)
			if !ok {
				respondWithError(w, http.StatusUnauthorized, "Claims invalides")
				return
			}

			// Extraire le userId du claim "id" (correspondant au JWT Node.js)
			userID, ok := claims["id"].(string)
			if !ok {
				respondWithError(w, http.StatusUnauthorized, "id manquant dans le token")
				return
			}

			// Ajouter le userId au contexte
			ctx := context.WithValue(r.Context(), "userId", userID)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// Fonction helper pour extraire le userId du contexte
func getUserIDFromContext(r *http.Request) (string, bool) {
	userID, ok := r.Context().Value("userId").(string)
	return userID, ok
}