package handlers

import (
	"math/big"
	"net/http"

	"blockchain-service/internal/config"
	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/service"
)

func GetStats(cfg *config.Config) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		userID, ok := getUserIDFromContext(r)
		if !ok {
			respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
			return
		}

		paramUserID := r.URL.Query().Get("userId")
		if paramUserID == "" {
			respondWithError(w, http.StatusBadRequest, "userId requis dans les paramètres de requête")
			return
		}

		if userID != paramUserID {
			respondWithError(w, http.StatusForbidden, "Accès non autorisé")
			return
		}

		client, err := ethereum.NewClient(cfg)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur connexion blockchain: "+err.Error())
			return
		}
		defer client.Close()

		walletAddress, err := service.GetWalletAddressForUser(paramUserID)
		if err != nil {
			respondWithError(w, http.StatusNotFound, "Wallet non trouvé: "+err.Error())
			return
		}

		// Récupérer les statistiques depuis le smart contract
		stats, err := client.GetStats(walletAddress)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur récupération statistiques: "+err.Error())
			return
		}

		// Formater la réponse exactement comme le frontend l'attend
		total := new(big.Int).Add(stats.Wallet.AvailableCredits, stats.Wallet.LockedCredits)
		responseData := map[string]interface{}{
			"wallet": map[string]interface{}{
				"available":  ethereum.WeiToEth(stats.Wallet.AvailableCredits),
				"locked":     ethereum.WeiToEth(stats.Wallet.LockedCredits),
				"total":      ethereum.WeiToEth(total),
				"address":    walletAddress.Hex(),
				"kycStatus":  stats.Wallet.KycStatus,
			},
			"today": map[string]interface{}{
				"sent":     ethereum.WeiToEth(stats.TodaySent),
				"received": ethereum.WeiToEth(stats.TodayReceived),
			},
			"monthly": map[string]interface{}{
				"sent":     ethereum.WeiToEth(stats.MonthlySent),
				"received": ethereum.WeiToEth(stats.MonthlyReceived),
			},
			"allTime": map[string]interface{}{
				"transactions": stats.AllTimeTransactions,
				"sent":         ethereum.WeiToEth(stats.AllTimeSent),
				"received":     ethereum.WeiToEth(stats.AllTimeReceived),
				"fees":         ethereum.WeiToEth(stats.AllTimeFees),
			},
		}

		respondWithJSON(w, http.StatusOK, true, "Statistiques récupérées avec succès", responseData)
	}
}