package handlers

import (
	"net/http"
	"strconv"
	"time"

	"blockchain-service/internal/config"
	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/service"
)

func GetHistory(cfg *config.Config) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		userID, ok := getUserIDFromContext(r)
		if !ok {
			respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
			return
		}

		// Récupérer les paramètres de requête
		paramUserID := r.URL.Query().Get("userId")
		if paramUserID == "" {
			respondWithError(w, http.StatusBadRequest, "userId requis dans les paramètres de requête")
			return
		}

		if userID != paramUserID {
			respondWithError(w, http.StatusForbidden, "Accès non autorisé")
			return
		}

		// Paramètres de pagination
		page, _ := strconv.Atoi(r.URL.Query().Get("page"))
		if page < 1 {
			page = 1
		}

		limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
		if limit < 1 || limit > 100 {
			limit = 20
		}

		startDate := r.URL.Query().Get("startDate")
		endDate := r.URL.Query().Get("endDate")

		// Convertir les dates en timestamp
		var startTimestamp, endTimestamp uint64
		if startDate != "" {
			if t, err := time.Parse(time.RFC3339, startDate); err == nil {
				startTimestamp = uint64(t.Unix())
			}
		}
		if endDate != "" {
			if t, err := time.Parse(time.RFC3339, endDate); err == nil {
				endTimestamp = uint64(t.Unix())
			}
		}

		client, err := ethereum.NewClient(cfg)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur connexion blockchain: "+err.Error())
			return
		}
		defer client.Close()

		// Obtenir l'adresse du wallet
		walletAddress, err := service.GetWalletAddressForUser(paramUserID)
		if err != nil {
			respondWithError(w, http.StatusNotFound, "Wallet non trouvé: "+err.Error())
			return
		}

		// Récupérer l'historique depuis le smart contract
		transactions, total, err := client.GetTransactionHistory(
			walletAddress,
			uint64(page-1), // Le contrat attend l'index de départ
			uint64(limit),
			startTimestamp,
			endTimestamp,
		)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur récupération historique: "+err.Error())
			return
		}

		// Formater les transactions comme attendu par le frontend
		formattedTransactions := make([]map[string]interface{}, len(transactions))
		for i, tx := range transactions {
			formattedTransactions[i] = map[string]interface{}{
				"id":              tx.ID.Hex(),
				"fromWalletId":    tx.From.Hex(),
				"toWalletId":      tx.To.Hex(),
				"amount":          ethereum.WeiToEth(tx.Amount),
				"fee":             ethereum.WeiToEth(tx.Fee),
				"transactionType": tx.TransactionType,
				"status":          tx.Status,
				"description":     tx.Description,
				"metadata":        map[string]interface{}{},
				"createdAt":       time.Unix(int64(tx.Timestamp), 0).Format(time.RFC3339),
				"fromWallet": map[string]interface{}{
					"id":            tx.From.Hex(),
					"userId":        "", // À récupérer depuis le mapping
					"walletAddress": tx.From.Hex(),
				},
				"toWallet": map[string]interface{}{
					"id":            tx.To.Hex(),
					"userId":        "", // À récupérer depuis le mapping
					"walletAddress": tx.To.Hex(),
				},
			}
		}

		totalPages := (int(total) + limit - 1) / limit

		responseData := map[string]interface{}{
			"transactions": formattedTransactions,
			"total":        total,
			"page":         page,
			"totalPages":   totalPages,
		}

		respondWithJSON(w, http.StatusOK, true, "Historique récupéré avec succès", responseData)
	}
}