package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"blockchain-service/internal/config"
	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/service"
)

func RequestWithdrawal(cfg *config.Config) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		userID, ok := getUserIDFromContext(r)
		if !ok {
			respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
			return
		}

		var request struct {
			WalletID    string                 `json:"walletId"`
			Amount      float64                `json:"amount"`
			BankDetails map[string]interface{} `json:"bankDetails"`
		}

		if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
			respondWithError(w, http.StatusBadRequest, "Body invalide: "+err.Error())
			return
		}

		if request.WalletID == "" {
			respondWithError(w, http.StatusBadRequest, "walletId requis dans le body")
			return
		}

		// Vérifier que le wallet appartient à l'utilisateur
		walletAddress, err := service.GetWalletAddressForUser(userID)
		if err != nil || walletAddress.Hex() != request.WalletID {
			respondWithError(w, http.StatusForbidden, "Accès non autorisé à ce wallet")
			return
		}

		client, err := ethereum.NewClient(cfg)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur connexion blockchain: "+err.Error())
			return
		}
		defer client.Close()

		// Convertir le montant en wei
		amountWei := ethereum.EthToWei(request.Amount)

		// Convertir les détails bancaires en JSON
		bankDetailsJSON, err := json.Marshal(request.BankDetails)
		if err != nil {
			respondWithError(w, http.StatusBadRequest, "Détails bancaires invalides")
			return
		}

		// Créer la demande de retrait sur la blockchain
		requestID, err := client.RequestWithdrawal(walletAddress, amountWei, string(bankDetailsJSON))
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur création demande de retrait: "+err.Error())
			return
		}

		// Récupérer les détails de la demande
		withdrawal, err := client.GetWithdrawalRequest(requestID)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur récupération demande: "+err.Error())
			return
		}

		responseData := map[string]interface{}{
			"id":        withdrawal.ID.Hex(),
			"walletId":  walletAddress.Hex(),
			"amount":    ethereum.WeiToEth(withdrawal.Amount),
			"fee":       ethereum.WeiToEth(withdrawal.Fee),
			"netAmount": ethereum.WeiToEth(withdrawal.NetAmount),
			"status":    withdrawal.Status,
			"createdAt": time.Unix(int64(withdrawal.CreatedAt), 0).Format(time.RFC3339),
		}

		respondWithJSON(w, http.StatusOK, true, "Demande de retrait créée avec succès", responseData)
	}
}