package handlers

import (
	"net/http"
	"time"

	"blockchain-service/internal/config"
	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/service"
)

func GenerateAuditReport(cfg *config.Config) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		userID, ok := getUserIDFromContext(r)
		if !ok {
			respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
			return
		}

		paramUserID := r.URL.Query().Get("userId")
		if paramUserID == "" {
			respondWithError(w, http.StatusBadRequest, "userId requis dans les paramètres de requête")
			return
		}

		startDate := r.URL.Query().Get("startDate")
		endDate := r.URL.Query().Get("endDate")

		if startDate == "" || endDate == "" {
			respondWithError(w, http.StatusBadRequest, "startDate et endDate requis")
			return
		}

		if userID != paramUserID {
			respondWithError(w, http.StatusForbidden, "Accès non autorisé")
			return
		}

		// Convertir les dates
		startTime, err := time.Parse(time.RFC3339, startDate)
		if err != nil {
			respondWithError(w, http.StatusBadRequest, "startDate invalide")
			return
		}

		endTime, err := time.Parse(time.RFC3339, endDate)
		if err != nil {
			respondWithError(w, http.StatusBadRequest, "endDate invalide")
			return
		}

		client, err := ethereum.NewClient(cfg)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur connexion blockchain: "+err.Error())
			return
		}
		defer client.Close()

		walletAddress, err := service.GetWalletAddressForUser(paramUserID)
		if err != nil {
			respondWithError(w, http.StatusNotFound, "Wallet non trouvé: "+err.Error())
			return
		}

		// Générer le rapport d'audit
		report, err := client.GenerateAuditReport(
			walletAddress,
			uint64(startTime.Unix()),
			uint64(endTime.Unix()),
		)
		if err != nil {
			respondWithError(w, http.StatusInternalServerError, "Erreur génération rapport: "+err.Error())
			return
		}

		// Formater la réponse
		formattedTransactions := make([]map[string]interface{}, len(report.Transactions))
		for i, tx := range report.Transactions {
			formattedTransactions[i] = map[string]interface{}{
				"id":        tx.ID.Hex(),
				"type":      tx.TransactionType,
				"amount":    ethereum.WeiToEth(tx.Amount),
				"fee":       ethereum.WeiToEth(tx.Fee),
				"direction": tx.Direction,
				"timestamp": time.Unix(int64(tx.Timestamp), 0).Format(time.RFC3339),
				"ledgerHash": tx.LedgerHash.Hex(),
			}
		}

		responseData := map[string]interface{}{
			"summary": map[string]interface{}{
				"totalTransactions":      report.Summary.TotalTransactions,
				"totalCreditsSent":       ethereum.WeiToEth(report.Summary.TotalCreditsSent),
				"totalCreditsReceived":   ethereum.WeiToEth(report.Summary.TotalCreditsReceived),
				"totalFees":              ethereum.WeiToEth(report.Summary.TotalFees),
				"period": map[string]interface{}{
					"startDate": startDate,
					"endDate":   endDate,
				},
			},
			"transactions": formattedTransactions,
		}

		respondWithJSON(w, http.StatusOK, true, "Rapport d'audit généré avec succès", responseData)
	}
}