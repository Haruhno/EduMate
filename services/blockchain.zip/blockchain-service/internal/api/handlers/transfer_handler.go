package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/config"
	"blockchain-service/internal/service"
)

// TransferHandler gère toutes les opérations de transfert
type TransferHandler struct {
	ethClient *ethereum.Client
	config    *config.Config
}

// NewTransferHandler crée un nouveau handler avec le client Ethereum injecté
func NewTransferHandler(ethClient *ethereum.Client, cfg *config.Config) *TransferHandler {
	return &TransferHandler{
		ethClient: ethClient,
		config:    cfg,
	}
}

// Transfer exécute un transfert de crédits
func (h *TransferHandler) Transfer(w http.ResponseWriter, r *http.Request) {
	userID, ok := getUserIDFromContext(r)
	if !ok {
		respondWithError(w, http.StatusUnauthorized, "Utilisateur non authentifié")
		return
	}

	var request struct {
		FromUserId      string      `json:"fromUserId"`
		ToWalletAddress string      `json:"toWalletAddress"`
		Amount          float64     `json:"amount"`
		Description     string      `json:"description,omitempty"`
		Metadata        interface{} `json:"metadata,omitempty"`
	}

	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		respondWithError(w, http.StatusBadRequest, "Body invalide: "+err.Error())
		return
	}

	if request.FromUserId == "" {
		respondWithError(w, http.StatusBadRequest, "fromUserId requis dans le body")
		return
	}

	if userID != request.FromUserId {
		respondWithError(w, http.StatusForbidden, "Accès non autorisé")
		return
	}

	// Obtenir l'adresse de l'expéditeur
	fromAddress, err := service.GetWalletAddressForUser(request.FromUserId)
	if err != nil {
		respondWithError(w, http.StatusNotFound, "Wallet expéditeur non trouvé: "+err.Error())
		return
	}

	// Convertir l'adresse du destinataire
	toAddress, err := ethereum.StringToAddress(request.ToWalletAddress)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Adresse destinataire invalide: "+err.Error())
		return
	}

	// Convertir le montant en wei
	amountWei := ethereum.EthToWei(request.Amount)

	// Exécuter le transfert sur la blockchain
	txHash, err := h.ethClient.Transfer(fromAddress, toAddress, amountWei, request.Description, "EXCHANGE_SERVICE")
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Erreur transfert: "+err.Error())
		return
	}

	// Attendre la confirmation
	receipt, err := h.ethClient.WaitForTransactionReceipt(txHash)
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Erreur confirmation transaction: "+err.Error())
		return
	}

	// Récupérer les détails de la transaction
	transaction, err := h.ethClient.GetTransaction(txHash)
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Erreur récupération transaction: "+err.Error())
		return
	}

	// Formater la réponse comme attendue par le frontend
	createdAt := time.Unix(int64(transaction.Timestamp), 0).Format(time.RFC3339)
	responseData := map[string]interface{}{
		"transaction": map[string]interface{}{
			"id":              transaction.ID.Hex(),
			"fromWalletId":    fromAddress.Hex(),
			"toWalletId":      toAddress.Hex(),
			"amount":          request.Amount,
			"fee":             ethereum.WeiToEth(transaction.Fee),
			"transactionType": "EXCHANGE_SERVICE",
			"status":          "completed",
			"description":     request.Description,
			"metadata":        request.Metadata,
			"createdAt":       createdAt,
		},
		"ledgerBlock": map[string]interface{}{
			"id":        receipt.BlockNumber.Int64(),
			"hash":      receipt.BlockHash.Hex(),
			"timestamp": time.Now().Format(time.RFC3339),
		},
		"fromUser": map[string]interface{}{
			"name":       "Utilisateur",
			"newBalance": 0.0, // À calculer
		},
		"toUser": map[string]interface{}{
			"name": "Destinataire",
		},
	}

	respondWithJSON(w, http.StatusOK, true, "Transfert effectué avec succès", responseData)
}

// CreatePendingBooking crée une transaction pending pour une réservation
func (h *TransferHandler) CreatePendingBooking(w http.ResponseWriter, r *http.Request) {
	// Implémenter la logique de réservation pending
	respondWithJSON(w, http.StatusOK, true, "Transaction PENDING créée avec succès", map[string]interface{}{
		"transaction": map[string]interface{}{
			"id":      "pending-tx-id",
			"amount":  0,
			"status":  "pending",
			"metadata": map[string]interface{}{},
		},
		"ledgerBlock": map[string]interface{}{
			"id":        1,
			"hash":      "pending-hash",
			"timestamp": time.Now().Format(time.RFC3339),
		},
	})
}

// ConfirmBooking confirme une réservation
func (h *TransferHandler) ConfirmBooking(w http.ResponseWriter, r *http.Request) {
	// Implémenter la confirmation de réservation
	respondWithJSON(w, http.StatusOK, true, "Transaction confirmée avec succès", map[string]interface{}{})
}

// CancelBooking annule une réservation
func (h *TransferHandler) CancelBooking(w http.ResponseWriter, r *http.Request) {
	// Implémenter l'annulation de réservation
	respondWithJSON(w, http.StatusOK, true, "Transaction annulée avec succès", map[string]interface{}{})
}