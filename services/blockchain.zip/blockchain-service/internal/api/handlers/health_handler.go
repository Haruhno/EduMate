package handlers

import (
	"net/http"
	"time"

	"blockchain-service/internal/config"
	"blockchain-service/internal/blockchain/ethereum"
)

func HealthCheck(w http.ResponseWriter, r *http.Request) {
	response := map[string]interface{}{
		"status":  "OK",
		"service": "Blockchain Service",
		"timestamp": time.Now().Format(time.RFC3339),
	}

	respondWithJSON(w, http.StatusOK, true, "Service en ligne", response)
}

func TestConnection(w http.ResponseWriter, r *http.Request) {
	// Charger la config pour le test
	cfg := &config.Config{
		Ethereum: config.EthereumConfig{
			RPCURL: "http://localhost:8545",
		},
	}

	client, err := ethereum.NewClient(cfg)
	if err != nil {
		respondWithJSON(w, http.StatusOK, false, "Service blockchain inaccessible", map[string]interface{}{
			"error": err.Error(),
		})
		return
	}
	defer client.Close()

	// Tester la connexion
	chainID, err := client.GetChainID()
	if err != nil {
		respondWithJSON(w, http.StatusOK, false, "Connexion Ethereum échouée", map[string]interface{}{
			"error": err.Error(),
		})
		return
	}

	respondWithJSON(w, http.StatusOK, true, "Blockchain service fonctionne!", map[string]interface{}{
		"chainId":    chainID,
		"timestamp":  time.Now().Format(time.RFC3339),
		"blockchain": "Ethereum",
		"status":     "connected",
	})
}