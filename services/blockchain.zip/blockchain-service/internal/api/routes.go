package api

import (
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"

	"blockchain-service/internal/api/handlers"
	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/config"
)

func SetupRouter(cfg *config.Config, ethClient *ethereum.Client) *chi.Mux {
	r := chi.NewRouter()

	// ✅ Middlewares globaux AVANT toute route
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   []string{"http://localhost:5173", "http://localhost:3000"},
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-Requested-With"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// Initialiser les handlers
	walletHandler := handlers.NewWalletHandler(ethClient, cfg)
	transferHandler := handlers.NewTransferHandler(ethClient, cfg)

	// Routes publiques hors /api/blockchain
	r.Get("/health", handlers.HealthCheck)
	r.Get("/api/blockchain/test", walletHandler.TestConnection)

	// ===== Routes /api/blockchain =====
	r.Route("/api/blockchain", func(r chi.Router) {
		// ✅ CRÉER UN NOUVEAU ROUTER pour ce groupe
		// Cela évite le conflit avec .Use() après les routes

		// Route INTERNE protégée par token interne
		r.With(handlers.InternalServiceMiddleware(cfg.InternalServiceToken)).
			Post("/wallet/create", walletHandler.CreateWallet)

		// Groupe de routes PUBLIQUES avec middleware JWT
		r.Group(func(r chi.Router) {
			// ✅ Middleware JWT appliqué à ce groupe
			r.Use(handlers.AuthMiddleware(cfg.JWT.Secret))

			r.Get("/balance", walletHandler.GetBalance)
			r.Post("/transfer", transferHandler.Transfer)
			r.Get("/history", walletHandler.GetHistory)
			r.Post("/withdrawal/request", walletHandler.RequestWithdrawal)
			r.Get("/stats", walletHandler.GetStats)
			r.Get("/audit", walletHandler.GenerateAuditReport)

			// Routes pour réservations (compatibilité)
			r.Post("/transfer/booking-pending", transferHandler.CreatePendingBooking)
			r.Post("/transfer/booking-confirm", transferHandler.ConfirmBooking)
			r.Post("/transfer/booking-cancel", transferHandler.CancelBooking)
		})
	})

	return r
}