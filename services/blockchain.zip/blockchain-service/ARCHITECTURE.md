# Architecture Auth ↔ Blockchain Service

## 🔴 Problèmes Identifiés

### 1. **Pas de création de wallet automatique à l'inscription**

#### Flux actuel ❌
```
AuthService.register()
  ├─ Create User in PostgreSQL
  ├─ Generate JWT
  └─ Return (user, jwt)
  
  ❌ MANQUE : POST /blockchain/wallet/create
```

#### Flux attendu ✅
```
AuthService.register()
  ├─ Create User in PostgreSQL (WITHOUT walletAddress)
  ├─ POST /blockchain/wallet/create → Get walletAddress
  ├─ UPDATE User.walletAddress in PostgreSQL
  ├─ Generate JWT
  └─ Return (user, jwt)
```

---

### 2. **Données en mémoire non persistantes**

#### Problème
- `walletAddress` est stockée uniquement en cache (map)
- Si le service redémarre → **toutes les adresses sont perdues** 🔥
- Pas de synchronisation avec PostgreSQL

#### Solution
```go
// ❌ ACTUEL
var userWallets = make(map[string]common.Address)

// ✅ À FAIRE
// Stocker en PostgreSQL : User.walletAddress
// Le cache en mémoire peut rester pour la performance
```

---

### 3. **Adresse déterministe au lieu de vrai wallet**

#### Problème
```go
// GetWalletAddressForUser génère une adresse si elle n'existe pas
// Mais ce n'est PAS un vrai wallet créé sur la blockchain !
return generateDeterministicAddress(userID)  // ❌ Faux
```

#### Conséquence
- L'utilisateur a une adresse "virtuelle"
- Pas de clé privée stockée
- Les transactions échoueront

#### Solution
- Créer un vrai wallet avec `CreateWalletForUser`
- Stocker la clé privée de manière sécurisée (Redis ou autre)
- Retourner erreur si wallet n'existe pas

---

### 4. **Pas de vérification à la connexion**

#### Flux actuel ❌
```
AuthService.login()
  ├─ Find User in PostgreSQL
  ├─ Validate Password
  └─ Return JWT
  
  ❌ MANQUE : Vérifier si User.walletAddress existe
```

#### Flux attendu ✅
```
AuthService.login()
  ├─ Find User in PostgreSQL
  ├─ Validate Password
  ├─ IF User.walletAddress IS NULL:
  │   └─ POST /blockchain/wallet/create → Get walletAddress
  │       └─ UPDATE User.walletAddress
  ├─ Generate JWT
  └─ Return (user, jwt)
```

---

## 📋 Plan d'Action

### Phase 1: Base de données
```sql
-- Dans User (PostgreSQL)
ALTER TABLE users ADD COLUMN walletAddress VARCHAR(255) UNIQUE;
```

### Phase 2: AuthService modifications
```javascript
// register endpoint
async register(userData) {
  const user = await User.create(userData);
  
  // 1️⃣ Créer le wallet
  const walletRes = await axios.post(
    'http://blockchain-service:3003/api/blockchain/wallet/create',
    { userId: user.id },
    { headers: { Authorization: `Bearer ${adminToken}` } }
  );
  
  // 2️⃣ Stocker l'adresse en PostgreSQL
  user.walletAddress = walletRes.data.data.walletAddress;
  await user.save();
  
  // 3️⃣ Retourner avec le wallet
  return { user, jwt };
}

// login endpoint
async login(email, password) {
  const user = await User.findOne({ email });
  if (!user) throw new Error('User not found');
  
  // 1️⃣ Vérifier le mot de passe
  if (!user.verifyPassword(password)) {
    throw new Error('Invalid password');
  }
  
  // 2️⃣ Vérifier/créer le wallet
  if (!user.walletAddress) {
    const walletRes = await axios.post(
      'http://blockchain-service:3003/api/blockchain/wallet/create',
      { userId: user.id },
      { headers: { Authorization: `Bearer ${adminToken}` } }
    );
    user.walletAddress = walletRes.data.data.walletAddress;
    await user.save();
  }
  
  // 3️⃣ Générer JWT
  return { user, jwt };
}
```

### Phase 3: BlockchainService modifications

#### wallet_service.go
```go
// ✅ Amélioration : Vérifier si wallet existe réellement
func GetWalletAddressForUser(userID string) (common.Address, error) {
  userWalletsLock.RLock()
  address, exists := userWallets[userID]
  userWalletsLock.RUnlock()

  if exists {
    return address, nil
  }

  // ❌ NE PAS retourner d'adresse déterministe
  // ✅ Retourner erreur 
  return common.Address{}, fmt.Errorf("wallet not found for user %s", userID)
}

// ✅ Amélioration : Vérifier avant de recréer
func CreateWalletForUser(userID string, client *ethereum.Client) (common.Address, error) {
  userWalletsLock.RLock()
  if existingAddress, exists := userWallets[userID]; exists {
    userWalletsLock.RUnlock()
    return existingAddress, nil
  }
  userWalletsLock.RUnlock()

  // Générer et stocker...
  
  // ✅ IMPORTANT: Le wallet est maintenant créé et prêt
}
```

---

## 🔐 Flux Final (Vision Globale)

```
┌─────────────────────────────────────────────────────────┐
│                   Utilisateur                            │
└───────────────────────┬─────────────────────────────────┘
                        │
            ┌───────────┴───────────┐
            │                       │
      ┌─────▼──────┐         ┌──────▼──────┐
      │ AuthService│         │Auth Frontend│
      └─────┬──────┘         └──────┬──────┘
            │                       │
      1. register/login             │
      2. create wallet ─────────────┤
      3. store walletAddress        │
      4. return JWT ◄───────────────┘
            │
            └────────────────┬───────────────────┐
                       HTTP Bearer JWT
            ┌────────────────▼──────────────────┐
            │   BlockchainService (Go)          │
            │  - Handle HTTP requests           │
            │  - Manage wallets in-memory       │
            │  - Interact with smart contracts  │
            └────────────────┬──────────────────┘
                             │
                    ┌────────┴────────┐
                    │                 │
            ┌───────▼────┐    ┌───────▼────┐
            │  Ganache   │    │ PostgreSQL  │
            │ (Ethereum) │    │ (User data) │
            └────────────┘    └─────────────┘
```

---

## ✅ Checklist

- [ ] Ajouter `walletAddress` à la table User (PostgreSQL)
- [ ] Modifier `register()` pour créer le wallet automatiquement
- [ ] Modifier `login()` pour créer le wallet si absent
- [ ] Améliorer `GetWalletAddressForUser()` pour retourner erreur si absent
- [ ] Ajouter un cache Redis pour stocker walletAddress (optionnel mais recommandé)
- [ ] Tester le flux complet: register → wallet creation → login → transfer

---

## 🚀 Résultat Attendu

| Action | Avant ❌ | Après ✅ |
|--------|---------|---------|
| Nouvel utilisateur → wallet ? | Non | Oui (auto) |
| Redémarrage service → wallet perdu ? | Oui | Non (en BD) |
| Login sans wallet → créer ? | Non | Oui (auto) |
| Adresse réelle ou déterministe ? | Déterministe (faux) | Réelle (vrai) |
