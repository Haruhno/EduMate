# 🔧 Guide d'Implémentation: Auth ↔ Blockchain Sync

## Résumé des Problèmes

| # | Problème | Impact | Solution |
|---|----------|--------|----------|
| 1 | Pas de création wallet à l'inscription | Utilisateur créé sans wallet | Appeler POST /wallet/create après register |
| 2 | Wallet en cache mémoire seulement | Données perdues au redémarrage | Stocker `walletAddress` en PostgreSQL |
| 3 | Adresse déterministe au lieu de vrai wallet | Transactions impossibles | Créer un vrai wallet avec clé privée |
| 4 | Pas de vérification à la connexion | Wallet absent reste absent | Créer wallet manquant au login |

---

## ✅ Implémentation Étape par Étape

### Étape 1: Corriger l'import cassé (URGENT)

**Fichier:** `services/blockchain-service/internal/service/wallet_service.go`

Ligne 11 est cassée:
```go
"github.com/ethereum/go-ethere	um/crypto"  // ❌ CASSÉ (espaces/tabulation)
```

Doit être:
```go
"github.com/ethereum/go-ethereum/crypto"  // ✅ CORRECT
```

---

### Étape 2: Ajouter walletAddress à User (PostgreSQL)

**AuthService:**

```javascript
// migration.js ou dans User.js model
const userSchema = new Schema({
  // Champs existants
  email: String,
  passwordHash: String,
  // ...
  
  // ✅ NOUVEAU
  walletAddress: {
    type: String,
    unique: true,
    sparse: true,  // Permet les NULL
    default: null
  }
});
```

---

### Étape 3: Synchroniser register()

**AuthService: routes/auth.js**

```javascript
router.post('/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // 1️⃣ Créer l'utilisateur SANS walletAddress
    const user = await User.create({
      email,
      passwordHash: await hashPassword(password),
      // walletAddress reste NULL
    });

    // 2️⃣ Créer le wallet via BlockchainService
    const blockchainServiceURL = 'http://blockchain-service:3003';
    const walletRes = await axios.post(
      `${blockchainServiceURL}/api/blockchain/wallet/create`,
      { userId: user._id.toString() },
      {
        headers: {
          'Authorization': `Bearer ${process.env.INTERNAL_SERVICE_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );

    if (!walletRes.data.success) {
      throw new Error('Failed to create wallet: ' + walletRes.data.message);
    }

    // 3️⃣ Mettre à jour l'utilisateur avec l'adresse du wallet
    user.walletAddress = walletRes.data.data.walletAddress;
    await user.save();

    // 4️⃣ Générer JWT
    const token = generateJWT({ id: user._id });

    // 5️⃣ Retourner
    return res.json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: user.toJSON(),
        token
      }
    });

  } catch (error) {
    console.error('Register error:', error);
    return res.status(400).json({
      success: false,
      message: error.message
    });
  }
});
```

---

### Étape 4: Synchroniser login()

**AuthService: routes/auth.js**

```javascript
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // 1️⃣ Trouver l'utilisateur
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // 2️⃣ Vérifier le mot de passe
    const isValidPassword = await verifyPassword(password, user.passwordHash);
    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // 3️⃣ Vérifier/Créer le wallet si absent
    if (!user.walletAddress) {
      try {
        const blockchainServiceURL = 'http://blockchain-service:3003';
        const walletRes = await axios.post(
          `${blockchainServiceURL}/api/blockchain/wallet/create`,
          { userId: user._id.toString() },
          {
            headers: {
              'Authorization': `Bearer ${process.env.INTERNAL_SERVICE_TOKEN}`,
              'Content-Type': 'application/json'
            }
          }
        );

        if (walletRes.data.success) {
          user.walletAddress = walletRes.data.data.walletAddress;
          await user.save();
          console.log(`✅ Wallet created for user ${user._id}: ${user.walletAddress}`);
        } else {
          console.warn(`⚠️ Failed to create wallet for user ${user._id}`);
          // Continuer quand même (l'utilisateur peut créer le wallet manuellement)
        }
      } catch (error) {
        console.error('Error creating wallet during login:', error.message);
        // Ne pas bloquer le login si le wallet n'a pas pu être créé
      }
    }

    // 4️⃣ Générer JWT
    const token = generateJWT({ id: user._id });

    // 5️⃣ Retourner
    return res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: user.toJSON(),
        token
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});
```

---

### Étape 5: Protéger le endpoint /wallet/create

**BlockchainService: routes.go**

```go
// Le endpoint /wallet/create doit vérifier le token du service interne
// PAS les tokens des utilisateurs normaux

// Dans un AuthMiddleware spécial pour les services internes
func InternalServiceMiddleware(internalToken string) func(http.Handler) http.Handler {
  return func(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
      token := r.Header.Get("Authorization")
      
      // Format: "Bearer <token>"
      if len(token) < 7 || token[:7] != "Bearer " {
        respondWithError(w, http.StatusUnauthorized, "Invalid token format")
        return
      }
      
      tokenString := token[7:]
      
      // Vérifier le token interne
      if tokenString != internalToken {
        respondWithError(w, http.StatusUnauthorized, "Invalid internal service token")
        return
      }
      
      next.ServeHTTP(w, r)
    })
  }
}

// Dans SetupRouter
r.Route("/api/blockchain", func(r chi.Router) {
  // Route INTERNE (sans JWT user)
  r.With(InternalServiceMiddleware(cfg.InternalServiceToken)).Post("/wallet/create", handlers.CreateWallet(cfg))
  
  // Routes PUBLIQUES (avec JWT user)
  r.Use(handlers.AuthMiddleware(cfg.JWT.Secret))
  r.Get("/balance", handlers.GetBalance(cfg))
  r.Post("/transfer", handlers.Transfer(cfg))
  // ...
})
```

---

### Étape 6: Améliorer GetWalletAddressForUser

**BlockchainService: service/wallet_service.go**

```go
// ✅ AVANT: Retournait une adresse déterministe (FAUX)
func GetWalletAddressForUser(userID string) (common.Address, error) {
  userWalletsLock.RLock()
  address, exists := userWallets[userID]
  userWalletsLock.RUnlock()

  if exists {
    return address, nil
  }

  // ❌ AVANT: return generateDeterministicAddress(userID), nil
  
  // ✅ APRÈS: Retourner erreur si wallet n'existe pas
  return common.Address{}, fmt.Errorf("wallet not found for user %s. User must call POST /wallet/create first", userID)
}

// ✅ NOUVEAU: Vérifier si le wallet existe déjà avant de recréer
func CreateWalletForUser(userID string, client *ethereum.Client) (common.Address, error) {
  // Vérifier que le wallet n'existe pas déjà
  userWalletsLock.RLock()
  if existingAddress, exists := userWallets[userID]; exists {
    userWalletsLock.RUnlock()
    fmt.Printf("✅ Wallet already exists for user %s: %s\n", userID, existingAddress.Hex())
    return existingAddress, nil
  }
  userWalletsLock.RUnlock()

  // Créer une nouvelle paire de clés
  privateKey, err := crypto.GenerateKey()
  if err != nil {
    return common.Address{}, fmt.Errorf("failed to generate key: %w", err)
  }

  publicKey := privateKey.Public()
  publicKeyECDSA, ok := publicKey.(*ecdsa.PublicKey)
  if !ok {
    return common.Address{}, fmt.Errorf("failed to convert public key")
  }

  address := crypto.PubkeyToAddress(*publicKeyECDSA)

  // Stocker le mapping en cache
  userWalletsLock.Lock()
  userWallets[userID] = address
  userWalletsLock.Unlock()

  fmt.Printf("✅ Wallet created for user %s: %s\n", userID, address.Hex())
  
  // ⚠️ NOTE: La clé privée est générée mais pas stockée nulle part
  // À considérer: Stocker en Redis ou autre vault sécurisé
  
  return address, nil
}
```

---

## 📊 Flux Testé

```
1. POST /register
   ├─ Create User (walletAddress = NULL)
   ├─ POST /wallet/create → Get address
   ├─ UPDATE User.walletAddress
   └─ Return JWT ✅

2. POST /login
   ├─ Find User
   ├─ Check Password
   ├─ IF walletAddress IS NULL:
   │   └─ POST /wallet/create → Get address + UPDATE ✅
   ├─ Generate JWT
   └─ Return JWT ✅

3. Service Redémarrage
   ├─ Cache vidé
   ├─ PostgreSQL a walletAddress ✅
   ├─ User peut faire une requête
   ├─ BlockchainService recharge depuis PostgreSQL (TODO)
   └─ Transaction possible ✅
```

---

## 🎯 Résultat Final

✅ **Utilisateur créé** → Wallet créé automatiquement  
✅ **Service redémarre** → Wallet récupéré depuis PostgreSQL  
✅ **Login sans wallet** → Wallet créé automatiquement  
✅ **Même utilisateur** → Même adresse wallet  
✅ **Transactions** → Possibles et sécurisées
