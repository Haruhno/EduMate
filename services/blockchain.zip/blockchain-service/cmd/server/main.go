package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"blockchain-service/internal/api"
	"blockchain-service/internal/blockchain/ethereum"
	"blockchain-service/internal/config"
)

func main() {
	// Charger la configuration
	cfg, err := config.LoadConfig()
	if err != nil {
		log.Fatalf("❌ Impossible de charger la config: %v", err)
	}

	// Créer le client Ethereum (UNE SEULE FOIS dans toute l'app)
	log.Println("🚀 Initialisation du client Ethereum...")
	ethClient, err := ethereum.NewClient(cfg)
	if err != nil {
		log.Fatalf("❌ Impossible de créer le client Ethereum: %v", err)
	}
	defer ethClient.Close()
	log.Println("✅ Client Ethereum initialisé")

	// Tester la connexion blockchain immédiatement
	chainID, err := ethClient.GetChainID()
	if err != nil {
		log.Fatalf("❌ Impossible de se connecter à la blockchain: %v", err)
	}
	log.Printf("✅ Connecté à la blockchain (Chain ID: %s)", chainID.String())

	// Initialiser l'API avec le client Ethereum
	router := api.SetupRouter(cfg, ethClient)

	// Démarrer le serveur
	server := &http.Server{
		Addr:    fmt.Sprintf(":%s", cfg.Port),
		Handler: router,
	}

	// Gestion propre de l'arrêt
	go func() {
		log.Printf("🌐 Blockchain Service démarré sur le port %s", cfg.Port)
		log.Printf("📡 RPC URL: %s", cfg.Ethereum.RPCURL)
		log.Printf("📝 Environnement: %s", cfg.Env)
		
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("❌ Erreur démarrage serveur: %v", err)
		}
	}()

	// Attendre le signal d'arrêt
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("🛑 Arrêt du serveur en cours...")
	
	log.Println("👋 Serveur arrêté")
}